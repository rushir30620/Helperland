"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var express_1 = __importDefault(require("express"));
var admin_repository_1 = require("../Admin Pages/admin.repository");
var admin_service_1 = require("../Admin Pages/admin.service");
var admin_controller_1 = require("../Admin Pages/admin.controller");
var user_repository_1 = require("../user/user.repository");
var user_service_1 = require("../user/user.service");
var user_controller_1 = require("../user/user.controller");
var router = express_1.default.Router();
var adminRepo = new admin_repository_1.AdminRepository();
var adminService = new admin_service_1.AdminService(adminRepo);
var adminController = new admin_controller_1.AdminController(adminService);
var userrepo = new user_repository_1.UserRepository();
var userservice = new user_service_1.UserService(userrepo);
var usercontroller = new user_controller_1.UserController(userservice);
/////////////////////////////////////////// 7.1 Service Request API //////////////////////////////////////////////////
router.get('/all-service-requests', usercontroller.validateTokenMiddleware, adminController.getAllServiceRequests);
router.put('/reschedule-edit-service/:serviceId', usercontroller.validateTokenMiddleware, adminController.rescheduleDateandTime, adminController.updateMyAddress);
/////////////////////////////////////////// 7.2 Filters API //////////////////////////////////////////////////
router.get('/search-by-serviceId', usercontroller.validateTokenMiddleware, adminController.searchByServiceId);
router.get('/search-by-postalcode', usercontroller.validateTokenMiddleware, adminController.searchByPostalcode);
router.get('/search-by-email', usercontroller.validateTokenMiddleware, adminController.searchByEmail);
router.get('/search-by-name', usercontroller.validateTokenMiddleware, adminController.searchByName);
router.get('/search-by-serviceProvider', usercontroller.validateTokenMiddleware, adminController.searchByServiceProvider);
router.get('/search-by-status', usercontroller.validateTokenMiddleware, adminController.searchByStatus);
router.get('/search-by-hasIssue', usercontroller.validateTokenMiddleware, adminController.searchByHasIssue);
router.get('/search-by-date', usercontroller.validateTokenMiddleware, adminController.searchByDate);
/////////////////////////////////////////// 7.3 User Management API //////////////////////////////////////////////////
router.get('/get-all-users', usercontroller.validateTokenMiddleware, adminController.getUserList);
router.put('/activate-or-deactivate/:userId', usercontroller.validateTokenMiddleware, adminController.activeUser, adminController.deactiveUser);
module.exports = router;
