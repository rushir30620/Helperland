import express from "express";
import { AdminRepository } from "../Admin Pages/admin.repository";
import { AdminService } from "../Admin Pages/admin.service";
import { AdminController } from "../Admin Pages/admin.controller";
import { UserRepository } from "../user/user.repository";
import { UserService } from "../user/user.service";
import { UserController } from "../user/user.controller";

const router: express.Router = express.Router();

const adminRepo: AdminRepository = new AdminRepository();
const adminService: AdminService = new AdminService(adminRepo);
const adminController: AdminController = new AdminController(adminService);

const userrepo: UserRepository = new UserRepository();
const userservice: UserService = new UserService(userrepo);
const usercontroller: UserController = new UserController(userservice);

/////////////////////////////////////////// 7.1 Service Request API //////////////////////////////////////////////////

router.get('/all-service-requests', usercontroller.validateTokenMiddleware, adminController.getAllServiceRequests);
router.put('/reschedule-edit-service/:serviceId', usercontroller.validateTokenMiddleware, adminController.rescheduleDateandTime, adminController.updateMyAddress);

/////////////////////////////////////////// 7.2 Filters API //////////////////////////////////////////////////

router.get('/search-by-serviceId', usercontroller.validateTokenMiddleware, adminController.searchByServiceId);
router.get('/search-by-postalcode', usercontroller.validateTokenMiddleware, adminController.searchByPostalcode);
router.get('/search-by-email', usercontroller.validateTokenMiddleware, adminController.searchByEmail);
router.get('/search-by-name', usercontroller.validateTokenMiddleware, adminController.searchByName);
router.get('/search-by-serviceProvider', usercontroller.validateTokenMiddleware, adminController.searchByServiceProvider);
router.get('/search-by-status', usercontroller.validateTokenMiddleware, adminController.searchByStatus);
router.get('/search-by-hasIssue', usercontroller.validateTokenMiddleware, adminController.searchByHasIssue);
router.get('/search-by-date', usercontroller.validateTokenMiddleware, adminController.searchByDate);

/////////////////////////////////////////// 7.3 User Management API //////////////////////////////////////////////////

router.get('/get-all-users', usercontroller.validateTokenMiddleware, adminController.getUserList);
router.put('/activate-or-deactivate/:userId', usercontroller.validateTokenMiddleware, adminController.activeUser, adminController.deactiveUser);


export = router;